export const apiUrl = process.env.NODE_ENV === 'production' ? process.env.REACT_APP_API_ENDPOINT : process.env.REACT_APP_DEV_API_ENDPOINT;
